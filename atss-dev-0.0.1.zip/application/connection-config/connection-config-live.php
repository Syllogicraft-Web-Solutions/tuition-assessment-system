<?php
	
	$environment = "development";

	define('BASE_URL', 'https://syllogicraft.000webhostapp.com/dev/');

	// DB Settings here
	define('DB_HOSTNAME', 'localhost');
	define('DB_USERNAME', 'id4060368_syllogicraft_atss');
	define('DB_PASSWORD', 'syllogicraft_atss12399');
	define('DB_DATABASE', 'id4060368_atss');
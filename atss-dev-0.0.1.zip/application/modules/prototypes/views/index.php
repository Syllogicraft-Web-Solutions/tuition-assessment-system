<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>

<header>

</header>

<section class="">
	
	<div class="hero-shot full-height full-width w3-display-container" style="">

		<div class="site-title w3-display-middle">
			<h1 class="w3-text-white w3-jumbo w3-center"> <?= $page_title ?> </h1>
			<h3 class="w3-text-white w3-jumbo w3-center"> Tang Ina </h3>
		</div>


	</div>

</section>

<div class="w3-container"></div>
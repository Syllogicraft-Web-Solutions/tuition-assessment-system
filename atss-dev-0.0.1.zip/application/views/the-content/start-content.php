<?php
	
	if ($with_sidebar) {

?>
	<div id="sidebar" style="margin-left: <?= $options['width'] ?>">

<?php 

	} else {
?>

	<div>

<?php
	}
<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!-- <?= $meta_name ?> -->
<meta name="<?= $name ?>" content="<?= $content ?>">
<?php
	
	$environment = "development";

	// define('BASE_URL', 'https://syllogicraft.000webhostapp.com/dev/');
	define('BASE_URL', 'http://syllogicraft.heliohost.org/');

	// DB Settings here
	// define('DB_HOSTNAME', 'localhost');
	// define('DB_USERNAME', 'id4060368_syllogicraft_atss');
	// define('DB_PASSWORD', 'syllogicraft_atss12399');
	// define('DB_DATABASE', 'id4060368_atss');

	define('DB_HOSTNAME', 'localhost');
	define('DB_USERNAME', 'syllogic_jimbo');
	define('DB_PASSWORD', 'jimbo99');
	define('DB_DATABASE', 'syllogic_atss');
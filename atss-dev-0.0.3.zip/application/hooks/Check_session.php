<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Check_session {
    public function __construct() {
            
    }

    public function __get($property) {
        if ( ! property_exists(get_instance(), $property)) {
                show_error('property: <strong>' . $property . '</strong> not exist.');
        }
        return get_instance()->$property;
    }
    public function validate() {

        if (in_array($this->router->class, array("Locationogin")))//login is a sample login controller {
            return;

        if (! $this->session->userdata('user_cookie')) 
            header('Location: ' . base_url('Login') . '?ref=' . $this->session->userdata('redirect_here')) ;
    }
}
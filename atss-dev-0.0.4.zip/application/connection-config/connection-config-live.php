<?php
	
	$environment = "development";

	// define('BASE_URL', 'https://syllogicraft.000webhostapp.com/dev/');
	// define('BASE_URL', 'http://syllogicraft.heliohost.org/');
	define('BASE_URL', 'http://syllogicraft.epizy.com/');

	// DB Settings here
	// define('DB_HOSTNAME', 'localhost');
	// define('DB_USERNAME', 'id4060368_syllogicraft_atss');
	// define('DB_PASSWORD', 'syllogicraft_atss12399');
	// define('DB_DATABASE', 'id4060368_atss');

	define('DB_HOSTNAME', 'sql100.epizy.com');
	define('DB_USERNAME', 'epiz_21301143');
	define('DB_PASSWORD', 'syllogicraft99');
	define('DB_DATABASE', 'epiz_21301143_atss');